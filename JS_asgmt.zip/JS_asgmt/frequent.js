function frequent()
{
    var p = document.getElementById("n").value;
    var arr = document.getElementById("a").value;
    var d = document.querySelector("#view");
    var arrd = document.querySelector("#arrayd");

    p=parseInt(p);
    var flag=true ,i,j;
    var arra= [];
    arrd.innerHTML="Array:"
    for(i=0; i<p; i++)
    {
     arra[i]= prompt('Enter Element ' + (i+1));
     arrd.innerHTML+= ' ' + arra[i];

    }
    // for(i=0; i<p; i++)
    // {
    // arrd.innerHTML="Array :" + arra[i];
    // }
    var mf =1;
    var m = 0;
    var item;
    
    for (var i = 0; i < arra.length; i++) {
      for (var j = i; j < arra.length; j++) {
        if (arra[i] == arra[j])
         m++;
        if (mf < m) {
          mf = m;
          item = arra[i];
        }
      }
    
      m = 0;
    }
    if(mf<2)
    {
        d.innerHTML="The frequency is same for all occurences";
    }
    else{
    d.innerHTML= "The" + ' '  + "number" + ' ' + item +' '+ "occured" + ' ' + mf + ' '+"times ";
    }
    
}