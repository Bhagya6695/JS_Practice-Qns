function letter()
{
    var d = document.querySelector("#disp");
    var arrd = document.querySelector("#arrayd");
    var i,j;
   var str="Javascript";
   var len=str.length;
   console.log(len);
   var out = ' '
   for (var i = 0; i <len; i++) {
    for (var j = i; j <= i; j++) {
        out += str[j] + '  ';
    }
    d.innerHTML+=out+"<br>";

}
}