function letter()
{
    var d = document.querySelector("#disp");
    var arrd = document.querySelector("#arrayd");
    var i,j;
   const str="Javascript";
var c=[];
for (const value of str) {
    c += value;
    d.innerHTML+=c+"<br>";
  }

}