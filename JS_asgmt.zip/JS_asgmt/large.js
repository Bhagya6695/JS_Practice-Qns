function findlarge()
{
var first = document.getElementById("n").value;
var second = document.getElementById("s").value;
  var d = document.querySelector("#view");
    first=Number(first);
    second=Number(second);
   if(first>second)
   {
       d.innerHTML=first+ ' '+"is the largest";
   }
   else{
    d.innerHTML= second + ' '+"is the largest";
   }
}