function oddeven()
{
    var d = document.querySelector("#disp");
    
    var i;
    for(i=0; i<=15; i++)
    {
        if(i%2 == 0)
        {
            d.innerHTML+=i + ' ' + "is" +' ' + "even"+"<br>";
        }
        else{
            d.innerHTML += i + ' ' + "is" + ' ' + "odd" +"<br>";
        }
    }
}