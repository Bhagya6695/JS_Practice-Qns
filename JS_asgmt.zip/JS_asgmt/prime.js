function prime()
{
    var p = document.getElementById("n").value;
    var arr = document.getElementById("a").value;
    var d = document.querySelector("#view");
    var arrd = document.querySelector("#arrayd");

    p=parseInt(p);
    
    var flag=true ,i,j;
    var arra= [];
    arrd.innerHTML="Array:"
    for(i=0; i<p; i++)
    {
     arra[i]= prompt('Enter Element ' + (i+1));
     arrd.innerHTML+= ' ' + arra[i];
    }
    var first=arra[0];
        for(j = 2; j <= first - 1; j++) 
    {
                if (first % j == 0) { 
                    flag = false; 
                    break; 
                } 
            }  
            
            if(arra.length =='')
            {
                d.innerHTML="Array size cannot be empty";
            }
                else if(flag==true && first!=1 && first!=0)
                {
                    
                    d.innerHTML= first + ' ' + "is  prime ";
                }
                else if(first==''|| first==" ")
                {
                    d.innerHTML="Array position is empty";
                }
                else{
                    d.innerHTML= "\n" + first + ' ' + "is !prime";
                }
            }