function sort()
{
    var p = document.getElementById("n").value;
    var arr = document.getElementById("a").value;
    var d = document.querySelector("#view");
    var arrd = document.querySelector("#arrayd");

    p=parseInt(p);
    
    var flag=true ,i,temp,i;
    var arra= [];
    arrd.innerHTML="Array:"
    for(i=0; i<p; i++)
    {
     arra[i]= prompt('Enter Element ' + (i+1));
     arrd.innerHTML+= ' ' + arra[i];
    }
    for(i=0; i<p; i++)
    {
        for(j=i+1;j<p;j++)
        {
            if(Number(arra[i])>Number(arra[j]))
            {
            temp=arra[i];
            arra[i]=arra[j];
            arra[j]=temp;
            }
        }
    }
d.innerHTML="Array after sorting:"
    for(i=0;i<p;i++)
    {
        d.innerHTML+=' '+ arra[i];
    }
       
            }