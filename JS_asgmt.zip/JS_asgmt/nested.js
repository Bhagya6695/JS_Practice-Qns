function nested()
{
// var str = document.getElementById("n").value;
    var len = document.getElementById("a").value;
    // var arr = document.getElementById("a").value;
    var d = document.querySelector("#disp");
    var arrd = document.querySelector("#arrayd");
    var i,j;
   var out = ' '
   for (var i = 0; i <len; i++) {
    for (var j = i; j <= i; j++) {
        out += '*' + '  ';
    }
    d.innerHTML+=out+"<br>";

}
}