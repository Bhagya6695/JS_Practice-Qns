
function sort()
{
   var d= document.querySelector("#view");
var age = {
  Athira:26,
  Rahul:20,
  Rajeesh:34,
  Vijayan:54,
  Akhil:21,
  Suni:17
  };
  var sortar=[];
  for (var key in age) {
    sortar.push([key,age[key]]);
  }
    // var arr = data[key];
    // for (var i = 0; i < arr.length; i++) {
    //   var obj = arr[i];
    //      sortar.push(obj);
    sortar.sort(function(a, b) {
        return a[1] - b[1];
    });
    
  
//    objectArray.sort(function(element1,element2){
//      return element2.age - element1.age
//   });
// }
d.innerHTML= "<br>"+sortar+' ' + "<br>";
}