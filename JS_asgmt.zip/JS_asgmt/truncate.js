function truncate()
{
var str = document.getElementById("n").value;
var len = document.getElementById("s").value;
    // var arr = document.getElementById("a").value;
    var d = document.querySelector("#view");
    var arrd = document.querySelector("#arrayd");
    var i=0;
    // var str = prompt("Enter the string: ");
    
    if (str.length > len) {
        str = str.substring(0, len) + "...";
      }
    d.innerHTML="The resultant string is:"+' '+ str;
}