function square()
{
    var p = document.getElementById("n").value;
    var arr = document.getElementById("a").value;
    var d = document.querySelector("#view");
    var out = document.querySelector("#sum");
    var arrd = document.querySelector("#arrayd");

    p=parseInt(p);
    
    var flag=true ,i,j;
    var arra= [];
    var sqr = [];
    var sum=0;
    arrd.innerHTML="Array:"
    d.innerHTML="Resultant array:"
    for(i=0; i<p; i++)
    {
     arra[i]= prompt('Enter Element ' + (i+1));
     arrd.innerHTML+= ' ' + arra[i];
    }
    for(i=0;i<p;i++)
    {
        sqr[i]=arra[i]*arra[i];
        d.innerHTML+=' ' +sqr[i];
        sum=sum+sqr[i];

    }
out.innerHTML= "Sum of squares of the array :" + ' ' + sum;
}