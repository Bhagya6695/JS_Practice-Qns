function string()
{
    var str = document.getElementById("n").value;
    var d = document.querySelector("#view");
    var arrd = document.querySelector("#arrayd");
    var i=0;
    // var str = "Please Like Moi Profile Pic Broi";
    var res="";
    // arrd.innerHTML="Given string:"+str;
    for(i=0;i<str.length;i++)
    {
        var c = str[i];
        if(c===c.toUpperCase())
        {
          
            res+=c.toLowerCase();

        }

        else{
            
           res+=c.toUpperCase();

        }
    }
 d.innerHTML+= "The resultant string is :" +' ' + res;
}